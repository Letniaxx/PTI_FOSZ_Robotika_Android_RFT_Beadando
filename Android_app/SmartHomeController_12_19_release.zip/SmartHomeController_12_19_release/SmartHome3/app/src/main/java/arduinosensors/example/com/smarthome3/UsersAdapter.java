package arduinosensors.example.com.smarthome3;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by sont1 on 2017. 12. 07..
 */

public class UsersAdapter extends ArrayAdapter<Adapter> {
    public UsersAdapter(Context context, ArrayList<Adapter> users) {
        super(context, 0, users);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Adapter user = getItem(position);

        if (convertView == null) {
            LayoutInflater sontInflater = LayoutInflater.from(getContext());
            convertView = sontInflater.inflate(R.layout.custom_row,parent,false);
        }

        TextView one = (TextView) convertView.findViewById(R.id.textView);
        TextView two = (TextView) convertView.findViewById(R.id.textView2);

        one.setText(user.name);
        two.setText(user.hometown);

        convertView.setBackgroundColor(position % 2 == 0 ? Color.BLACK : Color.parseColor("#303030"));
        return convertView;

    }
}
