package arduinosensors.example.com.smarthome3;

/**
 * Created by sont1 on 2017. 12. 07..
 */

public class Adapter {
    public String name;
    public String hometown;

    public Adapter(String name, String address) {
        this.name = name;
        this.hometown = address;
    }
}

